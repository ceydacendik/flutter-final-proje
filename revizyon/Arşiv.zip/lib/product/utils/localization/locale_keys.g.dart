// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const home_title = 'home.title';
  static const home_pick_image = 'home.pick_image';
  static const home = 'home';
  static const jewelery_title = 'jewelery.title';
  static const jewelery = 'jewelery';
  static const products_title = 'products.title';
  static const products_jewelery = 'products.jewelery';
  static const products = 'products';
  static const onboarding_title = 'onboarding.title';
  static const onboarding = 'onboarding';

}
