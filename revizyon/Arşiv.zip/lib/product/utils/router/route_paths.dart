enum RoutePaths {
  initial('/'),
  home('/home'),
  jewel('/jewel'),
  jewelery('/post'),
  onboarding('/onboarding'),
  ;

  const RoutePaths(this.path);
  final String path;
}
