import 'package:flutter/material.dart';

@immutable
final class StringConstant {
  const StringConstant._();

  static const String appName = 'Flutter Demo';
}
