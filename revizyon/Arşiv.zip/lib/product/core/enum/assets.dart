// enum Assets {
//   icIphone('iphone'),
//   imgIphone('iphone'),
//   imgMacbook('macbook'),
//   imgMacbookTwo('macbook2');

//   final String value;

//   const Assets(this.value);

//   String get toImage => 'assets/images/$value.png';
//   String get toSvg => 'assets/images/$value.svg';
// }
