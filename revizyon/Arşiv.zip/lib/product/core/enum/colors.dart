// import 'package:flutter/material.dart';

// enum MyColors {
//   /// A color constant representing the color red.
//   red('FF0000'),

//   /// A color constant representing the color green.
//   green('00FF00'),

//   /// A color constant representing the color blue.
//   blue('0000FF'),

//   /// A color constant representing the color yellow.
//   yellow('FFFF00');

//   /// The hexadecimal value of the color.
//   final String value;

//   const MyColors(this.value);

//   /// Returns the color value as a [Color] object.
//   Color get toColor => Color(int.parse('0xFF$value', radix: 16));
// }
