#!/bin/bash

# build_runner'ı kullanarak dosyaları oluştur
dart run build_runner build --delete-conflicting-outputs
